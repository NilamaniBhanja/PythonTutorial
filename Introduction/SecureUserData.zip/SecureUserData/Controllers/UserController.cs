using System;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SecureUserData.Common;
using SecureUserData.Models;
using SecureUserData.Services;

namespace SecureUserData.Controllers
{
    [Route("api/user")]
    public class UserController : Controller
    {
        private readonly IUserService _userService = new UserService();

        // 1) Helper: plain JSON in -> encrypted string out
        [HttpPost("encrypt")]
        public async Task<IActionResult> UserEncrypt()
        {
            string body;

            using (var reader = new StreamReader(Request.Body))
            {
                body = await reader.ReadToEndAsync();
            }

            JToken token;

            try
            {
                token = JToken.Parse(body);
            }
            catch (JsonReaderException)
            {
                return BadRequest("Body must be valid JSON.");
            }

            // Encrypt as an OBJECT (not as a string)
            string encrypted = AESCryptography.EncryptRequest<JToken>(token);

            return Content(encrypted, "text/plain", Encoding.UTF8);
        }
        // 2) Secure registration: encrypted in -> encrypted out
        [HttpPost, Route("secure-register")]
        public ApiResponse SecureRegistration(
    [FromBody] EncryptedRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Request))
                return Build(Fail("Request is required."));

            User userObj;
            try
            {
                userObj = CryptoHelper.SafeDecrypt<User>(request.Request);
            }
            catch (FormatException) { return Build(Fail("Request is not valid Base64.")); }
            catch (CryptographicException) { return Build(Fail("Unable to decrypt request.")); }
            catch (JsonException) { return Build(Fail("Decrypted data is not a valid user.")); }

            var errors = UserValidator.Validate(userObj);
            if (errors.Count > 0)
            {
                var failed = Fail("Validation failed.");
                failed.Errors = errors;
                return Build(failed);
            }

            UserResponse result = _userService.Register(userObj);
            return Build(result);
        }

        // 3) Helper: decrypt the response
        [HttpPost, Route("decrypt")]
        public UserResponse UserDecrypt([FromBody] DecryptedRequest request)
        {
            return AESCryptography.DecryptRequest<UserResponse>(request.Request);
        }

        [HttpPost("decryptInput")]
        public async Task<IActionResult> UserDecrypt()
        {
            string body;

            using (var reader = new StreamReader(Request.Body))
            {
                body = await reader.ReadToEndAsync();
            }

            try
            {
                // Remove quotes if the encrypted value is sent as a JSON string
                string encryptedText = body.Trim().Trim('"');

                // Decrypt the encrypted value into a JSON object
                JToken decrypted = AESCryptography.DecryptRequest<JToken>(encryptedText);

                return Ok(decrypted);
            }
            catch (FormatException)
            {
                return BadRequest("Invalid encrypted Base64 value.");
            }
            catch (CryptographicException)
            {
                return BadRequest("Decryption failed. Invalid encrypted value or encryption key.");
            }
            catch (JsonException)
            {
                return BadRequest("Decrypted data is not valid JSON.");
            }
        }
        private static UserResponse Fail(string message) =>
            new UserResponse { Success = false, Message = message };

        private static ApiResponse Build(UserResponse r) => new ApiResponse
        {
            Success = r.Success,
            Response = AESCryptography.EncryptRequest<UserResponse>(r)
        };
    }
}
