using System;
using System.Collections.Generic;

namespace SecureUserData.Models
{
    public class EncryptedRequest { public string Request { get; set; } }
    public class DecryptedRequest { public string Request { get; set; } }

    // Plain envelope; Response holds the ENCRYPTED UserResponse
    public class ApiResponse
    {
        public bool Success { get; set; }
        public string Response { get; set; }
    }

    public class UserResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public Guid? UserId { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }
}
