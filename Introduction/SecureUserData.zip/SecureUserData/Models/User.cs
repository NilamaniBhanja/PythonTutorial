using System.ComponentModel.DataAnnotations;

namespace SecureUserData.Models
{
    public class User
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string UserName { get; set; }

        public string Mobile { get; set; }   // optional
        public string Email { get; set; }    // optional
    }
}
