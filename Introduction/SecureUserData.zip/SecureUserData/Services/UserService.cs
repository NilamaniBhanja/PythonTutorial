using System;
using SecureUserData.Models;

namespace SecureUserData.Services
{
    public interface IUserService { UserResponse Register(User user); }

    public class UserService : IUserService
    {
        public UserResponse Register(User user)
        {
            // TODO: replace with your DB insert (EF / Dapper / stored proc)
            return new UserResponse
            {
                Success = true,
                Message = "User registered successfully.",
                UserId = Guid.NewGuid(),
                Name = user.Name,
                UserName = user.UserName,
                Mobile = user.Mobile,
                Email = user.Email
            };
        }
    }
}
