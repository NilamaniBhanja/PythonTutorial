using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using SecureUserData.Models;

namespace SecureUserData.Services
{
    public static class UserValidator
    {
        private const int MaxName = 100;
        private const int MaxUserName = 50;
        // Indian mobile: ^[6-9]\d{9}$   |  any 10 digits: ^\d{10}$
        private static readonly Regex MobileRegex = new Regex(@"^\d{10}$", RegexOptions.Compiled);

        public static List<string> Validate(User user)
        {
            var errors = new List<string>();
            if (user == null) { errors.Add("Request body is empty."); return errors; }

            var results = new List<ValidationResult>();
            Validator.TryValidateObject(user, new ValidationContext(user), results, true);
            errors.AddRange(results.Select(r => r.ErrorMessage));

            if (user.Name != null && user.Name.Length > MaxName)
                errors.Add($"Name cannot exceed {MaxName} characters.");
            if (user.UserName != null && user.UserName.Length > MaxUserName)
                errors.Add($"UserName cannot exceed {MaxUserName} characters.");

            if (!string.IsNullOrWhiteSpace(user.Email) && !IsValidEmail(user.Email))
                errors.Add("Email format is invalid.");

            if (!string.IsNullOrWhiteSpace(user.Mobile) && !MobileRegex.IsMatch(user.Mobile))
                errors.Add("Mobile must be a 10-digit number.");

            return errors;
        }

        private static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email.Trim() && email.Contains("@") && email.Split('@')[1].Contains(".");
            }
            catch { return false; }
        }
    }
}
