using System;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace SecureUserData.Common
{
    public class AESCryptography
    {
        public static IConfiguration Configuration { get; set; } = null!;
        private static string? _requestKey;
        private static string? _requestSecret;
        readonly UTF8Encoding _enc;
        readonly RijndaelManaged _rcipher;
        readonly byte[] _key, _iv;
        /***
         * Encryption mode enumeration
         */
        private enum EncryptMode { ENCRYPT, DECRYPT };

        static readonly char[] CharacterMatrixForRandomIVStringGeneration = {
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '_'
        };
        public static void Initialize(IConfiguration configuration)
        {
            ArgumentNullException.ThrowIfNull(configuration);

            _requestKey = configuration["RequestKey"];
            _requestSecret = configuration["RequestSecret"];

            if (string.IsNullOrWhiteSpace(_requestKey))
                throw new InvalidOperationException(
                    "RequestKey is missing in appsettings.json");

            if (string.IsNullOrWhiteSpace(_requestSecret))
                throw new InvalidOperationException(
                    "RequestSecret is missing in appsettings.json");

            // Validate AES key and IV lengths
            if (Encoding.UTF8.GetByteCount(_requestKey) != 32)
                throw new InvalidOperationException(
                    "RequestKey must be exactly 32 bytes for AES-256.");

            if (Encoding.UTF8.GetByteCount(_requestSecret) != 16)
                throw new InvalidOperationException(
                    "RequestSecret must be exactly 16 bytes.");
        }

        public AESCryptography()
        {
            _enc = new UTF8Encoding();
            _rcipher = new RijndaelManaged();
            _rcipher.Mode = CipherMode.CBC;
            _rcipher.Padding = PaddingMode.PKCS7;
            _rcipher.KeySize = 256;
            _rcipher.BlockSize = 128;
            _key = new byte[32];
            _iv = new byte[_rcipher.BlockSize / 8];
        }

        private String encryptDecrypt(string _inputText, string _encryptionKey, EncryptMode _mode, string _initVector)
        {
            byte[] _ivBytes = new byte[16];
            string _out = "";// output string
            byte[] _pwd = Encoding.UTF8.GetBytes(_encryptionKey);
            _ivBytes = Encoding.UTF8.GetBytes(_initVector);

            int len = _pwd.Length;
            if (len > _key.Length)
            {
                len = _key.Length;
            }
            int ivLenth = _ivBytes.Length;
            if (ivLenth > _iv.Length)
            {
                ivLenth = _iv.Length;
            }

            Array.Copy(_pwd, _key, len);
            Array.Copy(_ivBytes, _iv, ivLenth);
            _rcipher.Key = _key;
            _rcipher.IV = _iv;

            if (_mode.Equals(EncryptMode.ENCRYPT))
            {
                //encrypt
                byte[] plainText = _rcipher.CreateEncryptor().TransformFinalBlock(_enc.GetBytes(_inputText), 0, _inputText.Length);
                _out = Convert.ToBase64String(plainText);
            }
            if (_mode.Equals(EncryptMode.DECRYPT))
            {
                //decrypt
                byte[] plainText = _rcipher.CreateDecryptor().TransformFinalBlock(Convert.FromBase64String(_inputText), 0, Convert.FromBase64String(_inputText).Length);
                _out = _enc.GetString(plainText);
            }
            _rcipher.Dispose();
            return _out;// return encrypted/decrypted string
        }

        public static string encrypt(string value, string key, string IV)
        {
            AESCryptography obj = new AESCryptography();
            return obj.encryptDecrypt(value, key, EncryptMode.ENCRYPT, IV);
        }

        public static string decrypt(string value, string key, string IV)
        {
            AESCryptography obj = new AESCryptography();
            return obj.encryptDecrypt(value, key, EncryptMode.DECRYPT, IV);
        }

        public static string getHash(string text, int length)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            StringBuilder hashString = new StringBuilder();
            foreach (byte x in hash)
            {
                hashString.Append(String.Format("{0:x2}", x));
            }
            if (length > hashString.Length)
            {
                return hashString.ToString();
            }
            else
            {
                return hashString.ToString().Substring(0, length);
            }
        }

        public static string EncryptRequest<T>(T model)
        {
            string json = JsonConvert.SerializeObject(model);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(_requestKey);
                aes.IV = Encoding.UTF8.GetBytes(_requestSecret);

                ICryptoTransform encryptor = aes.CreateEncryptor();

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    using (StreamWriter sw = new StreamWriter(cs))
                    {
                        sw.Write(json);
                    }

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public static T DecryptRequest<T>(string encryptedText)
        {
            byte[] cipherBytes = Convert.FromBase64String(encryptedText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(_requestKey);
                aes.IV = Encoding.UTF8.GetBytes(_requestSecret);

                ICryptoTransform decryptor = aes.CreateDecryptor();

                using (MemoryStream ms = new MemoryStream(cipherBytes))
                using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                using (StreamReader sr = new StreamReader(cs))
                {
                    string json = sr.ReadToEnd();

                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
        }

    }
}
