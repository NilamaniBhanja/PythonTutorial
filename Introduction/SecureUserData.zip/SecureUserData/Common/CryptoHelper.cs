using Newtonsoft.Json;

namespace SecureUserData.Common
{
    public static class CryptoHelper
    {
        // Uses AESCryptography as-is; only adds a tolerant fallback for
        // payloads that were encrypted from an already-serialized JSON string.
        public static T SafeDecrypt<T>(string encrypted)
        {
            try
            {
                return AESCryptography.DecryptRequest<T>(encrypted);
            }
            catch (JsonSerializationException)
            {
                string inner = AESCryptography.DecryptRequest<string>(encrypted);
                return JsonConvert.DeserializeObject<T>(inner);
            }
        }
    }
}
