using SecureUserData.Common;

var builder = WebApplication.CreateBuilder(args);

// Register controllers with Newtonsoft.Json
builder.Services
    .AddControllers()
    .AddNewtonsoftJson();

builder.Services.AddOpenApi();

// Initialize AES configuration
AESCryptography.Initialize(builder.Configuration);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.MapControllers();

app.Run();